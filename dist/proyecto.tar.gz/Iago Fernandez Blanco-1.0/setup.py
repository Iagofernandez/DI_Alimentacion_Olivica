import setuptools

setuptools.setup\
      (name='Iago Fernandez Blanco',
      version='1.0',
      description='TiendaOlivica',
      author='Iago Fernández Blanco',
       packages = setuptools.find_packages(),
       classifiers=[
             "Programming Language :: Python :: 3",
             "License :: OSI Approved :: MOT License"
       ],
       python_requires ='>=3.6',
      )